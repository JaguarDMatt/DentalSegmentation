function map = crfviterbi(net, x)
% crfviterbi Compute most likely targets given inputs (Viterbi decoding)
% function map = crfviterbi(net, x)
%
% x{s,i}(:)
% map(s,i)

error('not yet implemented')
