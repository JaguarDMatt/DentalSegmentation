crfchainDemo
crfTestLogisticRegression
crfchainTest

crf2Ddemo
crf2Ddemo('infEngineName','bploopy','data','digits','classifier','bp');

% crfInfTestHMMuntied % requires BNT
