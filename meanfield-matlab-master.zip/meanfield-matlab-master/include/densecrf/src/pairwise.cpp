/*
    Copyright (c) 2013, Philipp Krähenbühl
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
        * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
        * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
        * Neither the name of the Stanford University nor the
        names of its contributors may be used to endorse or promote products
        derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY Philipp Krähenbühl ''AS IS'' AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL Philipp Krähenbühl BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "pairwise.h"
#include <iostream>

Kernel::~Kernel() {
}
class DenseKernel: public Kernel {
protected:
	NormalizationType ntype_;
	KernelType ktype_;
	Permutohedral lattice_;
	Eigen::VectorXf norm_;
	Eigen::MatrixXf f_;
	Eigen::MatrixXf parameters_;
	void initLattice( const Eigen::MatrixXf & f ) {
		const int N = f.cols();
		lattice_.init( f );
		
		norm_ = lattice_.compute( Eigen::VectorXf::Ones( N ).transpose() ).transpose();
		
		if ( ntype_ == NO_NORMALIZATION ) {
			float mean_norm = 0;
			for ( int i=0; i<N; i++ )
				mean_norm += norm_[i];
			mean_norm = N / mean_norm;
			for ( int i=0; i<N; i++ )
				norm_[i] = mean_norm;
		}
		else if ( ntype_ == NORMALIZE_SYMMETRIC ) {
			for ( int i=0; i<N; i++ )
				norm_[i] = 1.0 / sqrt(norm_[i]+1e-20);
		}
		else {
			for ( int i=0; i<N; i++ )
				norm_[i] = 1.0 / (norm_[i]+1e-20);
		}
	}
	void filter( Eigen::MatrixXf & out, const Eigen::MatrixXf & in, bool transpose ) const {
		// Read in the values
		if( ntype_ == NORMALIZE_SYMMETRIC || (ntype_ == NORMALIZE_BEFORE && !transpose) || (ntype_ == NORMALIZE_AFTER && transpose))
			out = in*norm_.asDiagonal();
		else
			out = in;
	
		// Filter
		if( transpose )
			lattice_.compute( out, out, true );
		else
			lattice_.compute( out, out );
// 			lattice_.compute( out.data(), out.data(), out.rows() );
	
		// Normalize again
		if( ntype_ == NORMALIZE_SYMMETRIC || (ntype_ == NORMALIZE_BEFORE && transpose) || (ntype_ == NORMALIZE_AFTER && !transpose))
			out = out*norm_.asDiagonal();
	}
	// Compute d/df a^T*K*b
	Eigen::MatrixXf kernelGradient( const Eigen::MatrixXf & a, const Eigen::MatrixXf & b ) const {
		Eigen::MatrixXf g = 0*f_;
		lattice_.gradient( g.data(), a.data(), b.data(), a.rows() );
		return g;
	}
	Eigen::MatrixXf featureGradient( const Eigen::MatrixXf & a, const Eigen::MatrixXf & b ) const {
		if (ntype_ == NO_NORMALIZATION )
			return kernelGradient( a, b );
		else if (ntype_ == NORMALIZE_SYMMETRIC ) {
			Eigen::MatrixXf fa = lattice_.compute( a*norm_.asDiagonal(), true );
			Eigen::MatrixXf fb = lattice_.compute( b*norm_.asDiagonal() );
			Eigen::MatrixXf ones = Eigen::MatrixXf::Ones( a.rows(), a.cols() );
			Eigen::VectorXf norm3 = norm_.array()*norm_.array()*norm_.array();
			Eigen::MatrixXf r = kernelGradient( 0.5*( a.array()*fb.array() + fa.array()*b.array() ).matrix()*norm3.asDiagonal(), ones );
			return - r + kernelGradient( a*norm_.asDiagonal(), b*norm_.asDiagonal() );
		}
		else if (ntype_ == NORMALIZE_AFTER ) {
			Eigen::MatrixXf fb = lattice_.compute( b );
			
			Eigen::MatrixXf ones = Eigen::MatrixXf::Ones( a.rows(), a.cols() );
			Eigen::VectorXf norm2 = norm_.array()*norm_.array();
			Eigen::MatrixXf r = kernelGradient( ( a.array()*fb.array() ).matrix()*norm2.asDiagonal(), ones );
			return - r + kernelGradient( a*norm_.asDiagonal(), b );
		}
		else /*if (ntype_ == NORMALIZE_BEFORE )*/ {
			Eigen::MatrixXf fa = lattice_.compute( a, true );
			
			Eigen::MatrixXf ones = Eigen::MatrixXf::Ones( a.rows(), a.cols() );
			Eigen::VectorXf norm2 = norm_.array()*norm_.array();
			Eigen::MatrixXf r = kernelGradient( ( fa.array()*b.array() ).matrix()*norm2.asDiagonal(), ones );
			return -r+kernelGradient( a, b*norm_.asDiagonal() );
		}
	}
public:
	DenseKernel(const Eigen::MatrixXf & f, KernelType ktype, NormalizationType ntype):f_(f), ktype_(ktype), ntype_(ntype) {
		if (ktype_ == DIAG_KERNEL)
			parameters_ = Eigen::VectorXf::Ones( f.rows() );
		else if( ktype == FULL_KERNEL )
			parameters_ = Eigen::MatrixXf::Identity( f.rows(), f.rows() );
		initLattice( f );
	}
	virtual void apply( Eigen::MatrixXf & out, const Eigen::MatrixXf & Q ) const {
		filter( out, Q, false );
	}
	virtual void applyTranspose( Eigen::MatrixXf & out, const Eigen::MatrixXf & Q ) const {
		filter( out, Q, true );
	}
	virtual Eigen::VectorXf parameters() const {
		if (ktype_ == CONST_KERNEL)
			return Eigen::VectorXf();
		else if (ktype_ == DIAG_KERNEL)
			return parameters_;
		else {
			Eigen::MatrixXf p = parameters_;
			p.resize( p.cols()*p.rows(), 1 );
			return p;
		}
	}
	virtual void setParameters( const Eigen::VectorXf & p ) {
		if (ktype_ == DIAG_KERNEL) {
			parameters_ = p;
			initLattice( p.asDiagonal() * f_ );
		}
		else if (ktype_ == FULL_KERNEL) {
			Eigen::MatrixXf tmp = p;
			tmp.resize( parameters_.rows(), parameters_.cols() );
			parameters_ = tmp;
			initLattice( tmp * f_ );
		}
	}
	virtual Eigen::VectorXf gradient( const Eigen::MatrixXf & a, const Eigen::MatrixXf & b ) const {
		if (ktype_ == CONST_KERNEL)
			return Eigen::VectorXf();
		Eigen::MatrixXf fg = featureGradient( a, b );
		if (ktype_ == DIAG_KERNEL)
			return (f_.array()*fg.array()).rowwise().sum();
		else {
			Eigen::MatrixXf p = fg*f_.transpose();
			p.resize( p.cols()*p.rows(), 1 );
			return p;
		}
	}
};

PairwisePotential::~PairwisePotential(){
	delete compatibility_;
	delete kernel_;
}
PairwisePotential::PairwisePotential(const Eigen::MatrixXf & features, LabelCompatibility * compatibility, KernelType ktype, NormalizationType ntype) : compatibility_(compatibility) {
	kernel_ = new DenseKernel( features, ktype, ntype );
}
void PairwisePotential::apply(Eigen::MatrixXf & out, const Eigen::MatrixXf & Q) const {
	kernel_->apply( out, Q );
	
	// Apply the compatibility
	compatibility_->apply( out, out );
}
void PairwisePotential::applyTranspose(Eigen::MatrixXf & out, const Eigen::MatrixXf & Q) const {
	kernel_->applyTranspose( out, Q );
	// Apply the compatibility
	compatibility_->applyTranspose( out, out );
}
Eigen::VectorXf PairwisePotential::parameters() const {
	return compatibility_->parameters();
}
void PairwisePotential::setParameters( const Eigen::VectorXf & v ) {
	compatibility_->setParameters( v );
}
Eigen::VectorXf PairwisePotential::gradient( const Eigen::MatrixXf & b, const Eigen::MatrixXf & Q ) const {
	Eigen::MatrixXf filtered_Q = 0*Q;
	// You could reuse the filtered_b from applyTranspose
	kernel_->apply( filtered_Q, Q );
	return compatibility_->gradient(b,filtered_Q);
}
Eigen::VectorXf PairwisePotential::kernelParameters() const {
	return kernel_->parameters();
}
void PairwisePotential::setKernelParameters( const Eigen::VectorXf & v ) {
	kernel_->setParameters( v );
}
Eigen::VectorXf PairwisePotential::kernelGradient( const Eigen::MatrixXf & b, const Eigen::MatrixXf & Q ) const {
	Eigen::MatrixXf lbl_Q = 0*Q;
	// You could reuse the filtered_b from applyTranspose
	compatibility_->apply( lbl_Q, Q );
	return kernel_->gradient(b,lbl_Q);
}