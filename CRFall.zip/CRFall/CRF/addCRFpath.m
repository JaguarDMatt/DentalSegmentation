Base = 'C:\kmurphy\matlab\Wearables\UBCcode';

folders = {'CRF', 'CRF1D', 'CRF2D', ...
	   'BPMRF2',  'BPlattice2', 'BPlattice2\Lattice2',  'BPlattice2\MPI',...
	   'HMM', 'KPMtools', 'KPMstats', 'graph', ...
	  'Foreign/netlab/netlab3.3'};

for f=1:length(folders)
  addpath(fullfile(Base, folders{f}))
end
