In order to use the MSRC class you need to download and unpack 
1. Unary potentials from http://graphics.stanford.edu/projects/densecrf/unary/
2. MSRC-21 dataset from http://research.microsoft.com/en-us/projects/objectclassrecognition/
3. More accurate annotations http://graphics.stanford.edu/projects/densecrf/textonboost/

The code assumes the catalog structure to be:
/data/MSRC/HighQuality
/data/MSRC/Images
/data/MSRC/SegmentationsGTHighQuality
/data/MSRC/split
/data/MSRC/unary