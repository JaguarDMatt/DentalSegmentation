function engine = bruteForceMrf2Engine(E, nstates, varargin)

engine.type = 'bruteForceMrf2';
engine.nstates = nstates;
engine.E = E;
