Conditional Random Fields toolbox.
See here for details
http://www.cs.ubc.ca/~murphyk/Software/CRF/crf.html
